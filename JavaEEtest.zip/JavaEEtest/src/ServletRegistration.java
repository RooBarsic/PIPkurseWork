import myClasses.UserAccessController;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ServletRegistration")
public class ServletRegistration extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String login = request.getParameter("login");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        if((login == null) || (password == null) || (email == null)){
            response.sendRedirect("./project/registration.jsp");
        }

        int flag = UserAccessController.addNewUser(login, password, email);
        switch (flag){
            case 1 :    response.sendRedirect("./project/enter.jsp");
                        System.out.println(" Registration OK. New user was added { long : " + login + "; password : " + password + "; email : " + email + " }");
                        break;
            default:    response.sendRedirect("./project/registration.jsp");
                        System.out.println(" myClasses.User try to registrate login : " + login + " . But this login already exist ");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
