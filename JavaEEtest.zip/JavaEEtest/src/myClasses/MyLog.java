package myClasses;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;

public class MyLog {
    public static List< User> getUsersInfo() {
        List< User> userInfo = new ArrayList<>();
        try (Scanner scanner = new Scanner(new File("my_data.txt"))) {
            int kol = scanner.nextInt();
            for (int i = 0; i < kol; i++) {
                String login = scanner.next();
                String password = scanner.next();
                String email = scanner.next();
                int score = scanner.nextInt();
                userInfo.add(new User(login, password, email, score));
            }
        }
        catch (Exception e){
            e.printStackTrace();
            System.out.println(" ################################ error in getUsersInfo ");
        }
        return userInfo;
    }

    public static void saveUsers(List<User> users){
        try (PrintWriter printWriter = new PrintWriter(new File("my_data.txt"))) {
            printWriter.println(users.size());
            for (User user : users) {
                user.printUser(printWriter);
            }
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        }
    }

    public static void updateData(String login, int score){
        List<User> users = getUsersInfo();
        for(User user : users){
            if(login.equals(user.getLogin())){
                user.setNewScore(score);
                break;
            }
        }
        saveUsers(users);
    }
}
