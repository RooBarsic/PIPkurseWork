package myClasses;

import java.io.PrintWriter;
import java.util.Comparator;

public class User implements Comparable {
    private String login;
    private String password;
    private String email;
    private int score;

    User(String login, String password, String email){
        this.login = login;
        this.password = password;
        this.email = email;
        this.score = 0;
    }

    User(String login, String password, String email, int score){
        this.login = login;
        this.password = password;
        this.email = email;
        this.score = score;
    }

    public void printUser(PrintWriter printWriter){
        printWriter.println(login + " " + password + " " + email + " " + score);
    }

    public String getLogin(){
        return login;
    }

    public int getScore() { return score; }

    public void setNewScore(int score) {
        if(this.score < score) this.score = score;
    }

    public boolean checkPassword(String password){
        return (password.equals(this.password));
    }

    public void setPassword(String password){
        this.password = password;
    }

    public String getEmail(){
        return email;
    }

    @Override
    public int compareTo(Object o) {
        User t = (User) o;
        if(t.getScore() > score) return 2;
        return -2;
    }
}
