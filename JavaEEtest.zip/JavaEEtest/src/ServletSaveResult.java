import myClasses.MyLog;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@WebServlet(name = "ServletSaveResult")
public class ServletSaveResult extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("score = " + request.getParameter("score"));
        System.out.println(" #############33 bebebe ");
        Map mp = request.getParameterMap();
        mp.forEach((a,b)->{
            System.out.println(a + " ---- " + b);
        });
        Cookie[] cookies = request.getCookies();
        String login = null;
        int score = 0;
        if(request.getParameter("score") != null) score = Integer.parseInt(request.getParameter("score"));
        for(Cookie cook : cookies){
            if(cook.getName().equals("score")){
                int cookScore = Integer.parseInt(cook.getValue());
                if(score < cookScore) score = cookScore;
            }
            if(cook.getName().equals("access")){
                login = cook.getValue();
            }
        }
        // json web tooken
        // browser local storage
        if(login != null){
            MyLog.updateData(login, score);
        }
        System.out.println(" login = " + login + " score = " + score);
        //response.sendRedirect("./project/game.jsp");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
