import myClasses.UserAccessController;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "TestServlet")
public class TestServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String login = request.getParameter("login");
        String password = request.getParameter("password");

        System.out.println("compare 123 vs 321" + "123".compareTo("321"));
        System.out.println("compare 321 vs 123" + "321".compareTo("123"));
        System.out.println("compare 123 vs 123" + "123".compareTo("123"));

        int result = UserAccessController.checkUser(login, password);
        System.out.println( " result = " + result);
        if(result == 2){
            Cookie accessCookie = new Cookie("access", login);
            accessCookie.setMaxAge(60 * 60 * 24);
            response.addCookie(accessCookie);

            response.sendRedirect("./project/news.jsp");

            System.out.println(" Access OK ");
        }
        else if(result == 0){
            response.sendRedirect("./project/enter.jsp");
            System.out.println(" Wrong user name ");
        }
        else if(result == 1){
            response.sendRedirect("./project/enter.jsp");
            System.out.println(" Wrong password ");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
