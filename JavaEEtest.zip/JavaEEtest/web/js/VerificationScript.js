


jQuery(document).ready(function(){
    var userLogin = document.getElementById("ulogin");
    userLogin.addEventListener("keyup", function (ev) {
        alert(this.value);
        var login = this.value;
         document.getElementById("loginFeedback").value = "Error!!!";
    } ,false);
    var userEmail = document.getElementById("uemail");
    userEmail.addEventListener("keyup", function f(ev) {
        ev.valueOf();
    }, false);
    var userPassword = document.getElementById("upassword");
    userPassword.addEventListener("keyup", function (ev) {

    }, false);
});

var app=new Vue({
    el : '#content',
    data : {
        loginMessage : '',
        passwordMessage : '',
        mailMessage : ''
    },
    methods : {
        checkLogin : function (event) {
            
        },
        
    }
})